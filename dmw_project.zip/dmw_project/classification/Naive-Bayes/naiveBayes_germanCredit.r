# Contains function naiveBayes
library(e1071)
#converting dataset to data frame
credit <- read.csv(file="/home/saksham/dmw_project/german_credit.csv",head=TRUE,sep=",")

# MAking a model
m <- naiveBayes(as.factor(Creditability) ~ ., data = credit)
#Predictions based on Naive-Baye's Theorem
predict(m, credit[,1:21])

#Plotting a graph to indicate relation between AccountBalance & Creditability
x <- AccountBalance
y <- Creditability
plot(y,x,col = "blue",main = "AccountBalance & Creditability",
     abline(lm(x~y)),cex = 1.3,pch = 16,xlab = "Creditability",ylab = "AccountBalance Rank(1-4)")
