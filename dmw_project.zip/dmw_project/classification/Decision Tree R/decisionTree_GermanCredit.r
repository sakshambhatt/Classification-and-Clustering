# party package contains ctree() function; for decision tree
library(party)
# Importing csv file into a variable
credit <- read.csv(file="/home/saksham/dmw_project/german_credit.csv",head=TRUE,sep=",")
# Checking whether file has imported correctly
print(head(credit)) #Checking whether file has imported correctly
# input data
input.dat <- credit[c(1:1000),]

output.tree <- ctree(
  Creditability ~ .,
  data = input.dat)

plot(output.tree)
dev.off()


