# Taking dataset in
credit <- read.csv(file="/home/saksham/dmw_project/german_credit.csv",head=TRUE,sep=",")

# Age > 60 and number of credits > 2 => Creditability is probably 1

# k means summary
set.seed(20)
creditCluster <- kmeans(credit, 4, nstart = 20)
creditCluster

creditCluster$cluster <- as.factor(creditCluster$cluster)
# Making a ggplot
library(ggplot2)
ggplot(credit, aes(No_ofCredits_atBank, Age_years, color = Creditability)) + geom_point()
ggplot(credit, aes(No_ofCredits_atBank, Age_years, color = Creditability)) + geom_point()

