credit <- read.csv(file="/home/saksham/dmw_project/german_credit.csv",head=TRUE,sep=",")
# Load the data 

library(factoextra)
df <- credit

# Compute DBSCAN using fpc package
library(fpc)
set.seed(123)
db <- fpc::dbscan(df, eps = 0.15, MinPts = 5)
  
# Plot DBSCAN results
library(factoextra)
fviz_cluster(db, data = df, stand = FALSE,
             ellipse = FALSE, show.clust.cent = FALSE,
             geom = "point",palette = "jco", ggtheme = theme_classic())

print(db)
