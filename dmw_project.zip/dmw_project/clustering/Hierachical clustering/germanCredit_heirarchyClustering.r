# Taking dataset in
credit <- read.csv(file="/home/saksham/dmw_project/german_credit.csv",head=TRUE,sep=",")


clusters <- hclust(dist(credit))
plot(clusters)

clusterCut <- cutree(clusters, 4)
table(clusterCut, credit$Creditability)


clusters <- hclust(dist(credit), method = 'average')
plot(clusters)
